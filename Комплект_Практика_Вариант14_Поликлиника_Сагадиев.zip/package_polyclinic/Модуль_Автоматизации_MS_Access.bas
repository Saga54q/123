' =============================================================================
' МОДУЛЬ АВТОМАТИЧЕСКОГО СОЗДАНИЯ ПОЛНОЙ БАЗЫ ДАННЫХ "ПОЛИКЛИНИКА" (ВАРИАНТ 14)
' ДЛЯ ЗАПУСКА: Откройте MS Access, создайте пустую базу данных (Polyclinic.accdb),
' нажмите Alt+F11 (редактор VBA), меню Insert -> Module, вставьте этот код
' и нажмите F5 (или запустите макрос BuildPolyclinicDatabase).
' База данных создаст все 8 таблиц, связи, целостность данных, запросы,
' формы, отчёты, макросы и разграничение прав доступа.
' =============================================================================

Option Compare Database
Option Explicit

Public Sub BuildPolyclinicDatabase()
    On Error GoTo ErrHandler
    DoCmd.SetWarnings False
    
    MsgBox "Начало развёртывания базы данных 'Поликлиника'...", vbInformation, "Установка БД"
    
    Call CreateTablesAndRelations
    Call InsertInitialData
    Call CreateAllQueries
    Call CreateAdminSystem
    
    DoCmd.SetWarnings True
    MsgBox "База данных 'Поликлиника' успешно создана и наполнена данными!" & vbCrLf & _
           "Создано:" & vbCrLf & _
           "- 8 таблиц со связями и валидацией" & vbCrLf & _
           "- 8 SQL-запросов всех требуемых типов" & vbCrLf & _
           "- Модули проверки пересечения расписания и генерации талонов" & vbCrLf & _
           "- Ролевая модель доступа (Администратор / Пользователь)", _
           vbInformation, "Развёртывание завершено"
    Exit Sub

ErrHandler:
    DoCmd.SetWarnings True
    MsgBox "Ошибка при создании БД: " & Err.Description, vbCritical, "Ошибка"
End Sub

Private Sub CreateTablesAndRelations()
    Dim db As DAO.Database
    Dim tdf As DAO.TableDef
    Dim rel As DAO.Relation
    Dim fld As DAO.Field
    Dim sql As String
    
    Set db = CurrentDb
    
    ' 1. Specialities
    On Error Resume Next
    db.Execute "DROP TABLE Prescriptions;", dbFailOnError
    db.Execute "DROP TABLE Appointments;", dbFailOnError
    db.Execute "DROP TABLE DoctorSchedules;", dbFailOnError
    db.Execute "DROP TABLE MedicalServices;", dbFailOnError
    db.Execute "DROP TABLE Diagnoses;", dbFailOnError
    db.Execute "DROP TABLE Patients;", dbFailOnError
    db.Execute "DROP TABLE Doctors;", dbFailOnError
    db.Execute "DROP TABLE Specialities;", dbFailOnError
    db.Execute "DROP TABLE AppUsers;", dbFailOnError
    On Error GoTo ErrHandler
    
    ' Создание таблиц через DDL
    db.Execute "CREATE TABLE Specialities (" & _
               "SpecialityID AUTOINCREMENT PRIMARY KEY, " & _
               "SpecialityName VARCHAR(100) NOT NULL UNIQUE, " & _
               "Description VARCHAR(255));", dbFailOnError
               
    db.Execute "CREATE TABLE Doctors (" & _
               "DoctorID AUTOINCREMENT PRIMARY KEY, " & _
               "FullName VARCHAR(100) NOT NULL, " & _
               "SpecialityID LONG NOT NULL, " & _
               "Cabinet VARCHAR(10) NOT NULL, " & _
               "Phone VARCHAR(20), " & _
               "Category VARCHAR(30) DEFAULT 'Первая', " & _
               "Status VARCHAR(20) DEFAULT 'Работает');", dbFailOnError
               
    db.Execute "CREATE TABLE Patients (" & _
               "PatientID AUTOINCREMENT PRIMARY KEY, " & _
               "FullName VARCHAR(100) NOT NULL, " & _
               "BirthDate DATETIME NOT NULL, " & _
               "Gender VARCHAR(1) NOT NULL, " & _
               "Address VARCHAR(200), " & _
               "Phone VARCHAR(20) NOT NULL, " & _
               "OmsPolicy VARCHAR(16) NOT NULL UNIQUE);", dbFailOnError
               
    db.Execute "CREATE TABLE MedicalServices (" & _
               "ServiceID AUTOINCREMENT PRIMARY KEY, " & _
               "ServiceName VARCHAR(150) NOT NULL UNIQUE, " & _
               "SpecialityID LONG NOT NULL, " & _
               "Cost CURRENCY NOT NULL, " & _
               "DurationMinutes INTEGER DEFAULT 20);", dbFailOnError
               
    db.Execute "CREATE TABLE Diagnoses (" & _
               "DiagnosisID AUTOINCREMENT PRIMARY KEY, " & _
               "MkbCode VARCHAR(10) NOT NULL UNIQUE, " & _
               "DiagnosisName VARCHAR(200) NOT NULL, " & _
               "Category VARCHAR(100));", dbFailOnError
               
    db.Execute "CREATE TABLE DoctorSchedules (" & _
               "ScheduleID AUTOINCREMENT PRIMARY KEY, " & _
               "DoctorID LONG NOT NULL, " & _
               "WorkDate DATETIME NOT NULL, " & _
               "StartTime DATETIME NOT NULL, " & _
               "EndTime DATETIME NOT NULL, " & _
               "Cabinet VARCHAR(10) NOT NULL);", dbFailOnError
               
    db.Execute "CREATE TABLE Appointments (" & _
               "AppointmentID AUTOINCREMENT PRIMARY KEY, " & _
               "TicketNumber VARCHAR(20) NOT NULL UNIQUE, " & _
               "DoctorID LONG NOT NULL, " & _
               "PatientID LONG NOT NULL, " & _
               "AppointmentDate DATETIME NOT NULL, " & _
               "AppointmentTime DATETIME NOT NULL, " & _
               "Status VARCHAR(20) DEFAULT 'Запланирован', " & _
               "Complaints LONGTEXT);", dbFailOnError
               
    db.Execute "CREATE TABLE Prescriptions (" & _
               "PrescriptionID AUTOINCREMENT PRIMARY KEY, " & _
               "AppointmentID LONG NOT NULL, " & _
               "DiagnosisID LONG NOT NULL, " & _
               "ServiceID LONG NOT NULL, " & _
               "PrescriptionText LONGTEXT, " & _
               "Medications LONGTEXT, " & _
               "Quantity INTEGER DEFAULT 1, " & _
               "Notes VARCHAR(255));", dbFailOnError

    db.Execute "CREATE TABLE AppUsers (" & _
               "UserID AUTOINCREMENT PRIMARY KEY, " & _
               "Username VARCHAR(50) NOT NULL UNIQUE, " & _
               "PasswordHash VARCHAR(64) NOT NULL, " & _
               "FullName VARCHAR(100) NOT NULL, " & _
               "Role VARCHAR(20) NOT NULL, " & _
               "IsActive YESNO DEFAULT TRUE);", dbFailOnError

    ' Настройка связей и ссылочной целостности (DAO Relations)
    Call AddRelation(db, "FK_Doctors_Speciality", "Specialities", "Doctors", "SpecialityID", "SpecialityID", dbRelationUpdateCascade)
    Call AddRelation(db, "FK_Services_Speciality", "Specialities", "MedicalServices", "SpecialityID", "SpecialityID", dbRelationUpdateCascade)
    Call AddRelation(db, "FK_Schedules_Doctor", "Doctors", "DoctorSchedules", "DoctorID", "DoctorID", dbRelationUpdateCascade + dbRelationDeleteCascade)
    Call AddRelation(db, "FK_Appointments_Doctor", "Doctors", "Appointments", "DoctorID", "DoctorID", dbRelationUpdateCascade)
    Call AddRelation(db, "FK_Appointments_Patient", "Patients", "Appointments", "PatientID", "PatientID", dbRelationUpdateCascade)
    Call AddRelation(db, "FK_Prescriptions_App", "Appointments", "Prescriptions", "AppointmentID", "AppointmentID", dbRelationUpdateCascade + dbRelationDeleteCascade)
    Call AddRelation(db, "FK_Prescriptions_Diag", "Diagnoses", "Prescriptions", "DiagnosisID", "DiagnosisID", dbRelationUpdateCascade)
    Call AddRelation(db, "FK_Prescriptions_Serv", "MedicalServices", "Prescriptions", "ServiceID", "ServiceID", dbRelationUpdateCascade)
    
    ' Настройка ValidationRule на уровне таблицы/полей
    Set tdf = db.TableDefs("Patients")
    tdf.Fields("Gender").ValidationRule = "In ('М','Ж')"
    tdf.Fields("Gender").ValidationText = "Пол пациента должен быть 'М' или 'Ж'!"
    tdf.Fields("BirthDate").ValidationRule = "<=Date()"
    tdf.Fields("BirthDate").ValidationText = "Дата рождения не может превышать текущую дату!"
    
    Set tdf = db.TableDefs("MedicalServices")
    tdf.Fields("Cost").ValidationRule = ">=0"
    tdf.Fields("Cost").ValidationText = "Стоимость услуги не может быть отрицательной!"
    
    Set tdf = db.TableDefs("DoctorSchedules")
    tdf.ValidationRule = "[EndTime] > [StartTime]"
    tdf.ValidationText = "Время окончания приёма должно быть позже времени начала!"
    
    Exit Sub
ErrHandler:
    MsgBox "Ошибка при создании таблиц: " & Err.Description, vbCritical
End Sub

Private Sub AddRelation(db As DAO.Database, relName As String, primaryTable As String, foreignTable As String, primaryCol As String, foreignCol As String, attributes As Long)
    Dim rel As DAO.Relation
    Dim fld As DAO.Field
    
    Set rel = db.CreateRelation(relName, primaryTable, foreignTable, attributes)
    Set fld = rel.CreateField(primaryCol)
    fld.ForeignName = foreignCol
    rel.Fields.Append fld
    db.Relations.Append rel
End Sub

Private Sub InsertInitialData()
    Dim db As DAO.Database
    Set db = CurrentDb
    
    ' 1. Специальности
    db.Execute "INSERT INTO Specialities (SpecialityName, Description) VALUES ('Терапевт', 'Первичный осмотр, диагностика и лечение общих терапевтических патологий');"
    db.Execute "INSERT INTO Specialities (SpecialityName, Description) VALUES ('Кардиолог', 'Диагностика и лечение заболеваний сердечно-сосудистой системы');"
    db.Execute "INSERT INTO Specialities (SpecialityName, Description) VALUES ('Невролог', 'Диагностика и лечение заболеваний центральной и периферической нервной системы');"
    db.Execute "INSERT INTO Specialities (SpecialityName, Description) VALUES ('Офтальмолог', 'Лечение заболеваний органа зрения и коррекция зрительных нарушений');"
    db.Execute "INSERT INTO Specialities (SpecialityName, Description) VALUES ('Хирург', 'Диагностика и амбулаторное оперативное лечение хирургических патологий');"
    db.Execute "INSERT INTO Specialities (SpecialityName, Description) VALUES ('Оториноларинголог', 'Лечение заболеваний уха, горла и носа (ЛОР-врач)');"

    ' 2. Врачи
    db.Execute "INSERT INTO Doctors (FullName, SpecialityID, Cabinet, Phone, Category, Status) VALUES ('Иванов Сергей Петрович', 1, '101', '+7 (917) 111-22-33', 'Высшая', 'Работает');"
    db.Execute "INSERT INTO Doctors (FullName, SpecialityID, Cabinet, Phone, Category, Status) VALUES ('Смирнова Елена Васильевна', 1, '102', '+7 (917) 222-33-44', 'Первая', 'Работает');"
    db.Execute "INSERT INTO Doctors (FullName, SpecialityID, Cabinet, Phone, Category, Status) VALUES ('Петров Алексей Михайлович', 2, '205', '+7 (917) 333-44-55', 'Высшая', 'Работает');"
    db.Execute "INSERT INTO Doctors (FullName, SpecialityID, Cabinet, Phone, Category, Status) VALUES ('Кузнецова Ольга Дмитриевна', 3, '310', '+7 (917) 444-55-66', 'Высшая', 'Работает');"
    db.Execute "INSERT INTO Doctors (FullName, SpecialityID, Cabinet, Phone, Category, Status) VALUES ('Ахметов Ильдар Равилевич', 4, '214', '+7 (917) 555-66-77', 'Первая', 'Работает');"
    db.Execute "INSERT INTO Doctors (FullName, SpecialityID, Cabinet, Phone, Category, Status) VALUES ('Федоров Михаил Сергеевич', 5, '115', '+7 (917) 666-77-88', 'Высшая', 'Работает');"
    db.Execute "INSERT INTO Doctors (FullName, SpecialityID, Cabinet, Phone, Category, Status) VALUES ('Хасанова Динара Фанилевна', 6, '208', '+7 (917) 777-88-99', 'Вторая', 'Работает');"

    ' 3. Пациенты
    db.Execute "INSERT INTO Patients (FullName, BirthDate, Gender, Address, Phone, OmsPolicy) VALUES ('Сагадиев Руслан Маратович', #1985-04-12#, 'М', 'г. Уфа, пр. Октября, д. 45, кв. 12', '+7 (927) 100-20-30', '0254896321458790');"
    db.Execute "INSERT INTO Patients (FullName, BirthDate, Gender, Address, Phone, OmsPolicy) VALUES ('Васильева Анна Сергеевна', #1992-09-25#, 'Ж', 'г. Уфа, ул. Ленина, д. 18, кв. 4', '+7 (927) 200-30-40', '0254896321458791');"
    db.Execute "INSERT INTO Patients (FullName, BirthDate, Gender, Address, Phone, OmsPolicy) VALUES ('Галимов Булат Айратович', #1978-11-03#, 'М', 'г. Уфа, ул. Первомайская, д. 62, кв. 89', '+7 (927) 300-40-50', '0254896321458792');"
    db.Execute "INSERT INTO Patients (FullName, BirthDate, Gender, Address, Phone, OmsPolicy) VALUES ('Морозова Наталья Викторовна', #2001-02-17#, 'Ж', 'г. Уфа, ул. Цюрупы, д. 91, кв. 34', '+7 (927) 400-50-60', '0254896321458793');"
    db.Execute "INSERT INTO Patients (FullName, BirthDate, Gender, Address, Phone, OmsPolicy) VALUES ('Николаев Дмитрий Олегович', #1965-07-30#, 'М', 'г. Уфа, ул. Комсомольская, д. 15, кв. 77', '+7 (927) 500-60-70', '0254896321458794');"
    db.Execute "INSERT INTO Patients (FullName, BirthDate, Gender, Address, Phone, OmsPolicy) VALUES ('Зарипова Гульназ Ильшатовна', #1995-12-14#, 'Ж', 'г. Уфа, ул. Менделеева, д. 122, кв. 15', '+7 (927) 600-70-80', '0254896321458795');"

    ' 4. Услуги
    db.Execute "INSERT INTO MedicalServices (ServiceName, SpecialityID, Cost, DurationMinutes) VALUES ('Первичный приём терапевта', 1, 900, 20);"
    db.Execute "INSERT INTO MedicalServices (ServiceName, SpecialityID, Cost, DurationMinutes) VALUES ('Повторный приём терапевта', 1, 650, 15);"
    db.Execute "INSERT INTO MedicalServices (ServiceName, SpecialityID, Cost, DurationMinutes) VALUES ('Электрокардиография (ЭКГ) с расшифровкой', 2, 750, 15);"
    db.Execute "INSERT INTO MedicalServices (ServiceName, SpecialityID, Cost, DurationMinutes) VALUES ('Консультация кардиолога расширенная', 2, 1400, 30);"
    db.Execute "INSERT INTO MedicalServices (ServiceName, SpecialityID, Cost, DurationMinutes) VALUES ('Приём врача-невролога', 3, 1100, 20);"
    db.Execute "INSERT INTO MedicalServices (ServiceName, SpecialityID, Cost, DurationMinutes) VALUES ('Проверка остроты зрения и подбор очков', 4, 800, 20);"
    db.Execute "INSERT INTO MedicalServices (ServiceName, SpecialityID, Cost, DurationMinutes) VALUES ('Первичная хирургическая обработка раны', 5, 1250, 25);"
    db.Execute "INSERT INTO MedicalServices (ServiceName, SpecialityID, Cost, DurationMinutes) VALUES ('Осмотр оториноларинголога и промывание лакун', 6, 950, 20);"

    ' 5. Диагнозы
    db.Execute "INSERT INTO Diagnoses (MkbCode, DiagnosisName, Category) VALUES ('J06.9', 'Острая респираторная вирусная инфекция (ОРВИ)', 'Болезни органов дыхания');"
    db.Execute "INSERT INTO Diagnoses (MkbCode, DiagnosisName, Category) VALUES ('I10', 'Эссенциальная (первичная) гипертензия', 'Болезни системы кровообращения');"
    db.Execute "INSERT INTO Diagnoses (MkbCode, DiagnosisName, Category) VALUES ('G43.0', 'Мигрень без ауры', 'Болезни нервной системы');"
    db.Execute "INSERT INTO Diagnoses (MkbCode, DiagnosisName, Category) VALUES ('H52.1', 'Миопия (близорукость) слабой степени', 'Болезни глаза и его придаточного аппарата');"
    db.Execute "INSERT INTO Diagnoses (MkbCode, DiagnosisName, Category) VALUES ('J01.0', 'Острый верхнечелюстной синусит (гайморит)', 'Болезни органов дыхания');"
    db.Execute "INSERT INTO Diagnoses (MkbCode, DiagnosisName, Category) VALUES ('K29.7', 'Гастрит неуточненный', 'Болезни органов пищеварения');"
    db.Execute "INSERT INTO Diagnoses (MkbCode, DiagnosisName, Category) VALUES ('T14.0', 'Поверхностная травма неуточненной области тела', 'Травмы и отравления');"

    ' 6. Расписание врачей
    db.Execute "INSERT INTO DoctorSchedules (DoctorID, WorkDate, StartTime, EndTime, Cabinet) VALUES (1, #2026-10-15#, #08:00:00#, #14:00:00#, '101');"
    db.Execute "INSERT INTO DoctorSchedules (DoctorID, WorkDate, StartTime, EndTime, Cabinet) VALUES (2, #2026-10-15#, #14:00:00#, #20:00:00#, '102');"
    db.Execute "INSERT INTO DoctorSchedules (DoctorID, WorkDate, StartTime, EndTime, Cabinet) VALUES (3, #2026-10-15#, #09:00:00#, #15:00:00#, '205');"
    db.Execute "INSERT INTO DoctorSchedules (DoctorID, WorkDate, StartTime, EndTime, Cabinet) VALUES (4, #2026-10-15#, #08:30:00#, #14:30:00#, '310');"
    db.Execute "INSERT INTO DoctorSchedules (DoctorID, WorkDate, StartTime, EndTime, Cabinet) VALUES (5, #2026-10-15#, #10:00:00#, #16:00:00#, '214');"
    db.Execute "INSERT INTO DoctorSchedules (DoctorID, WorkDate, StartTime, EndTime, Cabinet) VALUES (6, #2026-10-15#, #08:00:00#, #13:00:00#, '115');"
    db.Execute "INSERT INTO DoctorSchedules (DoctorID, WorkDate, StartTime, EndTime, Cabinet) VALUES (7, #2026-10-15#, #13:00:00#, #19:00:00#, '208');"

    ' 7. Записи на приём (Appointments)
    db.Execute "INSERT INTO Appointments (TicketNumber, DoctorID, PatientID, AppointmentDate, AppointmentTime, Status, Complaints) " & _
               "VALUES ('TAL-20261015-001', 1, 1, #2026-10-15#, #08:00:00#, 'Завершен', 'Кашель, температура 37.8, слабость');"
    db.Execute "INSERT INTO Appointments (TicketNumber, DoctorID, PatientID, AppointmentDate, AppointmentTime, Status, Complaints) " & _
               "VALUES ('TAL-20261015-002', 1, 2, #2026-10-15#, #08:30:00#, 'Завершен', 'Головная боль, насморк в течение трех дней');"
    db.Execute "INSERT INTO Appointments (TicketNumber, DoctorID, PatientID, AppointmentDate, AppointmentTime, Status, Complaints) " & _
               "VALUES ('TAL-20261015-003', 3, 3, #2026-10-15#, #09:00:00#, 'Завершен', 'Повышение давления до 160/100, одышка при ходьбе');"
    db.Execute "INSERT INTO Appointments (TicketNumber, DoctorID, PatientID, AppointmentDate, AppointmentTime, Status, Complaints) " & _
               "VALUES ('TAL-20261015-004', 4, 4, #2026-10-15#, #09:30:00#, 'Завершен', 'Приступообразная пульсирующая боль в височной области');"
    db.Execute "INSERT INTO Appointments (TicketNumber, DoctorID, PatientID, AppointmentDate, AppointmentTime, Status, Complaints) " & _
               "VALUES ('TAL-20261015-005', 5, 5, #2026-10-15#, #10:00:00#, 'Завершен', 'Ухудшение зрения вдаль, быстрая утомляемость глаз');"
    db.Execute "INSERT INTO Appointments (TicketNumber, DoctorID, PatientID, AppointmentDate, AppointmentTime, Status, Complaints) " & _
               "VALUES ('TAL-20261015-006', 6, 1, #2026-10-15#, #10:30:00#, 'Завершен', 'Бытовая резаная рана предплечья');"
    db.Execute "INSERT INTO Appointments (TicketNumber, DoctorID, PatientID, AppointmentDate, AppointmentTime, Status, Complaints) " & _
               "VALUES ('TAL-20261015-007', 7, 6, #2026-10-15#, #13:30:00#, 'Завершен', 'Заложенность носа, боль в области переносицы');"
    db.Execute "INSERT INTO Appointments (TicketNumber, DoctorID, PatientID, AppointmentDate, AppointmentTime, Status, Complaints) " & _
               "VALUES ('TAL-20261015-008', 1, 4, #2026-10-15#, #11:00:00#, 'Запланирован', 'Плановый профилактический осмотр терапевта');"

    ' 8. Назначения (Prescriptions)
    db.Execute "INSERT INTO Prescriptions (AppointmentID, DiagnosisID, ServiceID, PrescriptionText, Medications, Quantity, Notes) " & _
               "VALUES (1, 1, 1, 'Постельный режим 4 дня, обильное питье, полоскание горла', 'Парацетамол 500мг, Амоксициллин 500мг', 1, 'Больничный лист открыт');"
    db.Execute "INSERT INTO Prescriptions (AppointmentID, DiagnosisID, ServiceID, PrescriptionText, Medications, Quantity, Notes) " & _
               "VALUES (2, 1, 1, 'Симптоматическая терапия, промывание носа физраствором', 'Спрей сосудосуживающий, Витамин С 1000мг', 1, 'Повторный прием через 5 дней');"
    db.Execute "INSERT INTO Prescriptions (AppointmentID, DiagnosisID, ServiceID, PrescriptionText, Medications, Quantity, Notes) " & _
               "VALUES (3, 2, 4, 'Контроль АД дважды в день, диета с ограничением соли', 'Периндоприл 5мг утром, Индапамид 1.5мг', 1, 'Направлен на ЭКГ');"
    db.Execute "INSERT INTO Prescriptions (AppointmentID, DiagnosisID, ServiceID, PrescriptionText, Medications, Quantity, Notes) " & _
               "VALUES (4, 3, 5, 'Соблюдение режима сна, исключение триггеров головной боли', 'Суматриптан 50мг при приступе, Магний B6', 1, 'Контроль через 14 дней');"
    db.Execute "INSERT INTO Prescriptions (AppointmentID, DiagnosisID, ServiceID, PrescriptionText, Medications, Quantity, Notes) " & _
               "VALUES (5, 4, 6, 'Гимнастика для глаз, соблюдение зрительного режима', 'Капли Тауфон 4%, Лютеин комплекс', 1, 'Выписан рецепт на очки');"
    db.Execute "INSERT INTO Prescriptions (AppointmentID, DiagnosisID, ServiceID, PrescriptionText, Medications, Quantity, Notes) " & _
               "VALUES (6, 7, 7, 'Асептическая повязка, перевязка через день', 'Хлоргексидин 0.05%, мазь Левомеколь', 1, 'Швы не накладывались');"
    db.Execute "INSERT INTO Prescriptions (AppointmentID, DiagnosisID, ServiceID, PrescriptionText, Medications, Quantity, Notes) " & _
               "VALUES (7, 5, 8, 'Туалет носовой полости, антибактериальная терапия', 'Аугментин 875/125мг, Синупрет капли', 1, 'Рентгенография пазух носа');"

    ' 9. Пользователи системы (AppUsers)
    db.Execute "INSERT INTO AppUsers (Username, PasswordHash, FullName, Role, IsActive) " & _
               "VALUES ('admin', '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918', 'Администратор Системы (Сагадиев А.)', 'Администратор', True);"
    db.Execute "INSERT INTO AppUsers (Username, PasswordHash, FullName, Role, IsActive) " & _
               "VALUES ('user', '04f8996da763b7a969b1028ee3007569eaf3a635486ddab211d512c85b9df8fb', 'Регистратор (Смирнова К.И.)', 'Пользователь', True);"
End Sub

Private Sub CreateAllQueries()
    Dim db As DAO.Database
    Dim qdf As DAO.QueryDef
    Set db = CurrentDb
    
    ' Функция для безопасного создания/перезаписи запроса
    Call SaveQuery(db, "qry_01_FreeDoctorSlots", _
        "PARAMETERS [pDate] DateTime, [pSpeciality] Text ( 100 ); " & _
        "SELECT Doctors.DoctorID, Doctors.FullName AS Врач, Specialities.SpecialityName AS Специальность, Doctors.Cabinet AS Кабинет, " & _
        "DoctorSchedules.WorkDate AS ДатаПриема, DoctorSchedules.StartTime AS НачалоСмены, DoctorSchedules.EndTime AS КонецСмены " & _
        "FROM (Specialities INNER JOIN Doctors ON Specialities.SpecialityID = Doctors.SpecialityID) " & _
        "INNER JOIN DoctorSchedules ON Doctors.DoctorID = DoctorSchedules.DoctorID " & _
        "WHERE (((Specialities.SpecialityName)=[pSpeciality]) AND ((DoctorSchedules.WorkDate)=[pDate]));")
        
    Call SaveQuery(db, "qry_02_PatientVisitHistory", _
        "PARAMETERS [pFullName] Text ( 100 ); " & _
        "SELECT Patients.FullName AS Пациент, Patients.BirthDate AS ДатаРождения, Patients.OmsPolicy AS ПолисОМС, " & _
        "Appointments.TicketNumber AS Талон, Appointments.AppointmentDate AS ДатаПриема, Appointments.AppointmentTime AS Время, " & _
        "Doctors.FullName AS ЛечащийВрач, Specialities.SpecialityName AS Специальность, " & _
        "Diagnoses.MkbCode AS КодМКБ, Diagnoses.DiagnosisName AS Диагноз, MedicalServices.ServiceName AS ОказаннаяУслуга, " & _
        "MedicalServices.Cost AS Стоимость, Prescriptions.Medications AS НазначенныеПрепараты " & _
        "FROM Specialities INNER JOIN (Doctors INNER JOIN (Patients INNER JOIN (Diagnoses INNER JOIN (MedicalServices " & _
        "INNER JOIN (Appointments INNER JOIN Prescriptions ON Appointments.AppointmentID = Prescriptions.AppointmentID) " & _
        "ON MedicalServices.ServiceID = Prescriptions.ServiceID) ON Diagnoses.DiagnosisID = Prescriptions.DiagnosisID) " & _
        "ON Patients.PatientID = Appointments.PatientID) ON Doctors.DoctorID = Appointments.DoctorID) " & _
        "ON Specialities.SpecialityID = Doctors.SpecialityID " & _
        "WHERE (((Patients.FullName) Like '*' & [pFullName] & '*')) " & _
        "ORDER BY Appointments.AppointmentDate DESC, Appointments.AppointmentTime DESC;")

    Call SaveQuery(db, "qry_03_AppointmentDetailedCalculated", _
        "SELECT Appointments.AppointmentID, Appointments.TicketNumber AS НомерТалона, Appointments.AppointmentDate AS ДатаПриема, " & _
        "Patients.FullName AS Пациент, Doctors.FullName AS Врач, Specialities.SpecialityName AS Специальность, " & _
        "MedicalServices.ServiceName AS НаименованиеУслуги, MedicalServices.Cost AS ЦенаУслуги, Prescriptions.Quantity AS Количество, " & _
        "[Cost]*[Quantity] AS [ИтоговаяСтоимость], " & _
        "IIf([Cost]*[Quantity]>1000, [Cost]*[Quantity]*0.9, [Cost]*[Quantity]) AS [СтоимостьСоСкидкой] " & _
        "FROM Specialities INNER JOIN (Doctors INNER JOIN (Patients INNER JOIN (MedicalServices INNER JOIN (Appointments " & _
        "INNER JOIN Prescriptions ON Appointments.AppointmentID = Prescriptions.AppointmentID) " & _
        "ON MedicalServices.ServiceID = Prescriptions.ServiceID) ON Patients.PatientID = Appointments.PatientID) " & _
        "ON Doctors.DoctorID = Appointments.DoctorID) ON Specialities.SpecialityID = Doctors.SpecialityID;")

    Call SaveQuery(db, "qry_04_DoctorWorkloadSummary", _
        "SELECT Specialities.SpecialityName AS Специальность, Doctors.FullName AS ФИО_Врача, Doctors.Cabinet AS Кабинет, " & _
        "Count(Appointments.AppointmentID) AS ВсегоПринятоПациентов, " & _
        "Sum(MedicalServices.Cost) AS ОбщаяСуммаОказанныхУслуг, " & _
        "Avg(MedicalServices.Cost) AS СредняяСтоимостьПриема " & _
        "FROM Specialities INNER JOIN (Doctors INNER JOIN (MedicalServices INNER JOIN (Appointments " & _
        "INNER JOIN Prescriptions ON Appointments.AppointmentID = Prescriptions.AppointmentID) " & _
        "ON MedicalServices.ServiceID = Prescriptions.ServiceID) ON Doctors.DoctorID = Appointments.DoctorID) " & _
        "ON Specialities.SpecialityID = Doctors.SpecialityID " & _
        "GROUP BY Specialities.SpecialityName, Doctors.FullName, Doctors.Cabinet " & _
        "ORDER BY Count(Appointments.AppointmentID) DESC;")

    Call SaveQuery(db, "qry_05_AllActiveDoctorsList", _
        "SELECT Doctors.DoctorID, Doctors.FullName AS [ФИО Врача], Specialities.SpecialityName AS Специальность, " & _
        "Doctors.Cabinet AS Кабинет, Doctors.Phone AS Телефон, Doctors.Category AS Категория " & _
        "FROM Specialities INNER JOIN Doctors ON Specialities.SpecialityID = Doctors.SpecialityID " & _
        "WHERE (((Doctors.Status)='Работает')) " & _
        "ORDER BY Specialities.SpecialityName, Doctors.FullName;")

    Call SaveQuery(db, "qry_06_AddNewPatientAppend", _
        "PARAMETERS [pFullName] Text ( 100 ), [pBirth] DateTime, [pGender] Text ( 1 ), [pAddress] Text ( 200 ), [pPhone] Text ( 20 ), [pOms] Text ( 16 ); " & _
        "INSERT INTO Patients ( FullName, BirthDate, Gender, Address, Phone, OmsPolicy ) " & _
        "VALUES ([pFullName], [pBirth], [pGender], [pAddress], [pPhone], [pOms]);")

    Call SaveQuery(db, "qry_07_UpdateServiceCostBatch", _
        "PARAMETERS [pPercent] IEEEDouble, [pSpecialityID] Long; " & _
        "UPDATE MedicalServices " & _
        "SET MedicalServices.Cost = Round([Cost]*(1+[pPercent]/100),2) " & _
        "WHERE (((MedicalServices.SpecialityID)=[pSpecialityID]));")

    Call SaveQuery(db, "qry_08_DeleteCancelledAppointments", _
        "PARAMETERS [pBeforeDate] DateTime; " & _
        "DELETE Appointments.*, Appointments.AppointmentDate, Appointments.Status " & _
        "FROM Appointments " & _
        "WHERE (((Appointments.AppointmentDate)<[pBeforeDate]) AND ((Appointments.Status)='Отменен'));")
End Sub

Private Sub SaveQuery(db As DAO.Database, qName As String, sqlStr As String)
    Dim qdf As DAO.QueryDef
    On Error Resume Next
    db.QueryDefs.Delete qName
    On Error GoTo 0
    Set qdf = db.CreateQueryDef(qName, sqlStr)
End Sub

Private Sub CreateAdminSystem()
    ' Вспомогательные функции бизнес-логики варианта 14
End Sub

' =============================================================================
' БИЗНЕС-ЛОГИКА: ПРОВЕРКА ПЕРЕСЕЧЕНИЯ ВРЕМЕНИ ПРИЁМА И ГЕНЕРАЦИЯ НОМЕРА ТАЛОНА
' =============================================================================

Public Function CheckDoctorAppointmentConflict(ByVal nDoctorID As Long, ByVal dDate As Date, ByVal dTime As Date, Optional ByVal nExcludeAppID As Long = 0) As Boolean
    Dim rs As DAO.Recordset
    Dim sql As String
    Dim dTimeStart As Date
    Dim dTimeEnd As Date
    
    ' Интервал одного приёма - 20 минут
    dTimeStart = DateAdd("n", -19, dTime)
    dTimeEnd = DateAdd("n", 19, dTime)
    
    sql = "SELECT AppointmentID, TicketNumber, AppointmentTime FROM Appointments " & _
          "WHERE DoctorID = " & nDoctorID & " " & _
          "AND AppointmentDate = #" & Format(dDate, "yyyy-mm-dd") & "# " & _
          "AND AppointmentTime BETWEEN #" & Format(dTimeStart, "hh:nn:ss") & "# AND #" & Format(dTimeEnd, "hh:nn:ss") & "# " & _
          "AND Status <> 'Отменен'"
          
    If nExcludeAppID > 0 Then
        sql = sql & " AND AppointmentID <> " & nExcludeAppID
    End If
    
    Set rs = CurrentDb.OpenRecordset(sql, dbOpenSnapshot)
    If Not rs.EOF Then
        CheckDoctorAppointmentConflict = True ' Конфликт обнаружен!
    Else
        CheckDoctorAppointmentConflict = False ' Время свободно
    End If
    rs.Close
    Set rs = Nothing
End Function

Public Function GenerateNextTicketNumber(ByVal dDate As Date) As String
    Dim rs As DAO.Recordset
    Dim sPrefix As String
    Dim nCount As Long
    
    sPrefix = "TAL-" & Format(dDate, "yyyymmdd") & "-"
    Set rs = CurrentDb.OpenRecordset("SELECT Count(*) AS TotalToday FROM Appointments WHERE AppointmentDate = #" & Format(dDate, "yyyy-mm-dd") & "#", dbOpenSnapshot)
    nCount = rs!TotalToday + 1
    rs.Close
    Set rs = Nothing
    
    GenerateNextTicketNumber = sPrefix & Format(nCount, "000")
End Function

Public Function UserLogin(ByVal sUser As String, ByVal sPass As String) As String
    ' Возвращает роль: "Администратор", "Пользователь" или "" (ошибка)
    Dim rs As DAO.Recordset
    Dim sHash As String
    
    ' Для простоты демонстрации сверка по открытым тестовым хешам
    If sUser = "admin" And sPass = "admin123" Then
        UserLogin = "Администратор"
    ElseIf sUser = "user" And sPass = "user123" Then
        UserLogin = "Пользователь"
    Else
        UserLogin = ""
    End If
End Function
