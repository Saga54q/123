-- =============================================================================
-- СКРИПТ СОЗДАНИЯ СТРУКТУРЫ БАЗЫ ДАННЫХ MS ACCESS (SQL DDL)
-- ПРЕДМЕТНАЯ ОБЛАСТЬ: ПОЛИКЛИНИКА (ВАРИАНТ 14)
-- СТУДЕНТ: САГАДИЕВ АМИР
-- =============================================================================

-- 1. Таблица специальностей врачей
CREATE TABLE Specialities (
    SpecialityID AUTOINCREMENT CONSTRAINT PK_Specialities PRIMARY KEY,
    SpecialityName VARCHAR(100) NOT NULL CONSTRAINT UQ_SpecialityName UNIQUE,
    Description VARCHAR(255)
);

-- 2. Таблица врачей
CREATE TABLE Doctors (
    DoctorID AUTOINCREMENT CONSTRAINT PK_Doctors PRIMARY KEY,
    FullName VARCHAR(100) NOT NULL,
    SpecialityID LONG NOT NULL CONSTRAINT FK_Doctors_Speciality REFERENCES Specialities(SpecialityID) ON UPDATE CASCADE ON DELETE RESTRICT,
    Cabinet VARCHAR(10) NOT NULL,
    Phone VARCHAR(20),
    Category VARCHAR(30) DEFAULT 'Первая',
    Status VARCHAR(20) DEFAULT 'Работает'
);

-- 3. Таблица пациентов
CREATE TABLE Patients (
    PatientID AUTOINCREMENT CONSTRAINT PK_Patients PRIMARY KEY,
    FullName VARCHAR(100) NOT NULL,
    BirthDate DATETIME NOT NULL,
    Gender VARCHAR(1) NOT NULL,
    Address VARCHAR(200),
    Phone VARCHAR(20) NOT NULL,
    OmsPolicy VARCHAR(16) NOT NULL CONSTRAINT UQ_OmsPolicy UNIQUE
);

-- 4. Таблица медицинских услуг
CREATE TABLE MedicalServices (
    ServiceID AUTOINCREMENT CONSTRAINT PK_MedicalServices PRIMARY KEY,
    ServiceName VARCHAR(150) NOT NULL CONSTRAINT UQ_ServiceName UNIQUE,
    SpecialityID LONG NOT NULL CONSTRAINT FK_Services_Speciality REFERENCES Specialities(SpecialityID) ON UPDATE CASCADE ON DELETE RESTRICT,
    Cost CURRENCY NOT NULL,
    DurationMinutes INTEGER DEFAULT 20
);

-- 5. Таблица диагнозов (МКБ-10)
CREATE TABLE Diagnoses (
    DiagnosisID AUTOINCREMENT CONSTRAINT PK_Diagnoses PRIMARY KEY,
    MkbCode VARCHAR(10) NOT NULL CONSTRAINT UQ_MkbCode UNIQUE,
    DiagnosisName VARCHAR(200) NOT NULL,
    Category VARCHAR(100)
);

-- 6. Таблица расписания приёма врачей
CREATE TABLE DoctorSchedules (
    ScheduleID AUTOINCREMENT CONSTRAINT PK_DoctorSchedules PRIMARY KEY,
    DoctorID LONG NOT NULL CONSTRAINT FK_Schedules_Doctor REFERENCES Doctors(DoctorID) ON UPDATE CASCADE ON DELETE CASCADE,
    WorkDate DATETIME NOT NULL,
    StartTime DATETIME NOT NULL,
    EndTime DATETIME NOT NULL,
    Cabinet VARCHAR(10) NOT NULL
);

-- 7. Таблица записей на приём (талонов)
CREATE TABLE Appointments (
    AppointmentID AUTOINCREMENT CONSTRAINT PK_Appointments PRIMARY KEY,
    TicketNumber VARCHAR(20) NOT NULL CONSTRAINT UQ_TicketNumber UNIQUE,
    DoctorID LONG NOT NULL CONSTRAINT FK_Appointments_Doctor REFERENCES Doctors(DoctorID) ON UPDATE CASCADE ON DELETE RESTRICT,
    PatientID LONG NOT NULL CONSTRAINT FK_Appointments_Patient REFERENCES Patients(PatientID) ON UPDATE CASCADE ON DELETE RESTRICT,
    AppointmentDate DATETIME NOT NULL,
    AppointmentTime DATETIME NOT NULL,
    Status VARCHAR(20) DEFAULT 'Запланирован',
    Complaints MEMO
);

-- 8. Таблица назначений и оказанных услуг
CREATE TABLE Prescriptions (
    PrescriptionID AUTOINCREMENT CONSTRAINT PK_Prescriptions PRIMARY KEY,
    AppointmentID LONG NOT NULL CONSTRAINT FK_Prescriptions_Appointment REFERENCES Appointments(AppointmentID) ON UPDATE CASCADE ON DELETE CASCADE,
    DiagnosisID LONG NOT NULL CONSTRAINT FK_Prescriptions_Diagnosis REFERENCES Diagnoses(DiagnosisID) ON UPDATE CASCADE ON DELETE RESTRICT,
    ServiceID LONG NOT NULL CONSTRAINT FK_Prescriptions_Service REFERENCES MedicalServices(ServiceID) ON UPDATE CASCADE ON DELETE RESTRICT,
    PrescriptionText MEMO,
    Medications MEMO,
    Quantity INTEGER DEFAULT 1,
    Notes VARCHAR(255)
);
