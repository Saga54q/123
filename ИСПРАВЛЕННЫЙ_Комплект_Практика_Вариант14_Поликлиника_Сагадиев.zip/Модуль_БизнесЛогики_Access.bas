' =============================================================================
' МОДУЛЬ АВТОМАТИЗАЦИИ MS ACCESS: ПОЛИКЛИНИКА (ВАРИАНТ 14)
' =============================================================================

Option Compare Database
Option Explicit

Public Function ПроверитьПересечениеПриема(ByVal nКодВрача As Long, ByVal dДата As Date, ByVal dВремя As Date, Optional ByVal nИсключитьКодЗаписи As Long = 0) As Boolean
    Dim rs As DAO.Recordset
    Dim sql As String
    Dim dВремяНачало As Date
    Dim dВремяКонец As Date
    
    ' Интервал одного приёма врача - 20 минут
    dВремяНачало = DateAdd("n", -19, dВремя)
    dВремяКонец = DateAdd("n", 19, dВремя)
    
    sql = "SELECT [КодЗаписи], [НомерТалона] FROM [ЗаписиНаПрием] " & _
          "WHERE [КодВрача] = " & nКодВрача & " " & _
          "AND [ДатаПриема] = #" & Format(dДата, "yyyy-mm-dd") & "# " & _
          "AND [ВремяПриема] BETWEEN #" & Format(dВремяНачало, "hh:nn:ss") & "# AND #" & Format(dВремяКонец, "hh:nn:ss") & "# " & _
          "AND [Статус] <> 'Отменен'"
          
    If nИсключитьКодЗаписи > 0 Then
        sql = sql & " AND [КодЗаписи] <> " & nИсключитьКодЗаписи
    End If
    
    Set rs = CurrentDb.OpenRecordset(sql, dbOpenSnapshot)
    If Not rs.EOF Then
        ПроверитьПересечениеПриема = True ' Конфликт обнаружен
    Else
        ПроверитьПересечениеПриема = False ' Время свободно
    End If
    rs.Close
    Set rs = Nothing
End Function

Public Function СгенерироватьНомерТалона(ByVal dДата As Date) As String
    Dim rs As DAO.Recordset
    Dim sПрефикс As String
    Dim nВсего As Long
    
    sПрефикс = "TAL-" & Format(dДата, "yyyymmdd") & "-"
    Set rs = CurrentDb.OpenRecordset("SELECT Count(*) AS Всего FROM [ЗаписиНаПрием] WHERE [ДатаПриема] = #" & Format(dДата, "yyyy-mm-dd") & "#", dbOpenSnapshot)
    nВсего = rs!Всего + 1
    rs.Close
    Set rs = Nothing
    
    СгенерироватьНомерТалона = sПрефикс & Format(nВсего, "000")
End Function
